
const VERSION="d57e914d8f1dff";
const PREFIX='quiet-world:'+new URL(self.registration.scope).pathname+':';
const CACHE=PREFIX+VERSION;
self.addEventListener('install',event=>event.waitUntil((async()=>{
 const response=await fetch(new URL('asset-manifest.json',self.registration.scope),{cache:'no-store'});
 if(!response.ok)throw Error('Offline manifest unavailable');
 const manifest=await response.json();
 const cache=await caches.open(CACHE);
 await cache.addAll(manifest.assets.map(p=>new URL(p,self.registration.scope).href));
})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 for(const key of await caches.keys())if(key.startsWith(PREFIX)&&key!==CACHE)await caches.delete(key);
 await self.clients.claim();
 for(const client of await self.clients.matchAll())client.postMessage({type:'OFFLINE_READY'});
})()));
self.addEventListener('fetch',event=>{
 if(event.request.method!=='GET'||!event.request.url.startsWith(self.registration.scope))return;
 event.respondWith((async()=>{
  if(event.request.mode==='navigate'){
   try{const response=await fetch(event.request);if(response.ok)return response;}catch{}
   return await caches.match(new URL('index.html',self.registration.scope).href)||Response.error();
  }
  return await caches.match(event.request)||fetch(event.request);
 })());
});
